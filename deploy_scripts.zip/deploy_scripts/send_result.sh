#!/bin/bash

storescu 127.0.0.1 4242 -v -aec HIPPOAI /datadrive/out/report.dcm